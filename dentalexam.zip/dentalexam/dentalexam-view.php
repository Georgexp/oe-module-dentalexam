<?php
/**
 * @package   OpenEMR
 * @link      http://www.open-emr.org
 *
 * @author    OpenEMR
 * @copyright Copyright (c) 2022
 * @license   GNU General Public License 3
 */

use OpenEMR\Core\Header;

// Ensure proper includes are present
require_once dirname(__FILE__, 6) . '/globals.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo xlt('Dental Exam'); ?></title>
    <?php Header::setupHeader(['datetime-picker']); ?>
</head>
<body class="body_top">
    <div class="container mt-3">
        <h2><?php echo xlt('Dental Exam'); ?></h2>
        
        <form method="post" action="<?php echo $GLOBALS['webroot']; ?>/interface/modules/custom_modules/oe-module-dentalexam/public/save.php">
            <input type="hidden" name="csrf_token_form" value="<?php echo attr($csrfToken); ?>" />
            <input type="hidden" name="id" value="<?php echo attr($dentalExam->id ?? ''); ?>" />
            
            <div class="form-group">
                <div class="alert alert-info">
                    <strong><?php echo xlt('Legend:'); ?></strong> <?php echo xlt('A=Abscessed C=Caries F=Fracture E=Existing Restoration M=Mobile X=To be extracted'); ?>
                </div>
            </div>
            
            <div class="form-group">
                <label for="chief_complaint"><?php echo xlt('Chief Complaint:'); ?></label>
                <textarea name="chief_complaint" id="chief_complaint" class="form-control" rows="2"><?php echo text($dentalExam->chief_complaint ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="primary_diagnosis"><?php echo xlt('Primary Diagnosis:'); ?></label>
                <textarea name="primary_diagnosis" id="primary_diagnosis" class="form-control" rows="2"><?php echo text($dentalExam->primary_diagnosis ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="recommended_treatment"><?php echo xlt('Recommended Treatment:'); ?></label>
                <textarea name="recommended_treatment" id="recommended_treatment" class="form-control" rows="2"><?php echo text($dentalExam->recommended_treatment ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="procedures_performed"><?php echo xlt('Procedures Performed:'); ?></label>
                <textarea name="procedures_performed" id="procedures_performed" class="form-control" rows="2"><?php echo text($dentalExam->procedures_performed ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="medication_prescribed"><?php echo xlt('Medication Prescribed:'); ?></label>
                <textarea name="medication_prescribed" id="medication_prescribed" class="form-control" rows="2"><?php echo text($dentalExam->medication_prescribed ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="followup_next_visit"><?php echo xlt('Follow Up/Next Visit:'); ?></label>
                <input type="text" class="form-control datepicker" name="followup_next_visit" id="followup_next_visit" value="<?php echo attr($dentalExam->followup_next_visit ?? ''); ?>" />
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-save"><?php echo xlt('Save'); ?></button>
                <button type="button" class="btn btn-secondary btn-cancel" onclick="top.restoreSession(); parent.closeTab(window.name, false);"><?php echo xlt('Cancel'); ?></button>
            </div>
        </form>
    </div>
    
    <script>
        $(function() {
            $("#followup_next_visit").datetimepicker({
                timepicker: false,
                format: 'Y-m-d'
            });
        });
    </script>
</body>
</html>
