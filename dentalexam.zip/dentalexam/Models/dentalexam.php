<?php

namespace OpenEMR\Modules\DentalExam\Models;

/**
 * @package   OpenEMR
 * @link      http://www.open-emr.org
 *
 * @author    OpenEMR
 * @copyright Copyright (c) 2022
 * @license   GNU General Public License 3
 */

class DentalExam
{
    public $id;
    public $date;
    public $pid;
    public $encounter;
    public $user;
    public $groupname;
    public $authorized;
    public $activity;
    public $chief_complaint;
    public $primary_diagnosis;
    public $recommended_treatment;
    public $procedures_performed;
    public $medication_prescribed;
    public $followup_next_visit;
    
    public function __construct($data = null)
    {
        if (is_array($data)) {
            $this->id = $data['id'] ?? null;
            $this->date = $data['date'] ?? null;
            $this->pid = $data['pid'] ?? null;
            $this->encounter = $data['encounter'] ?? null;
            $this->user = $data['user'] ?? null;
            $this->groupname = $data['groupname'] ?? null;
            $this->authorized = $data['authorized'] ?? 0;
            $this->activity = $data['activity'] ?? 1;
            $this->chief_complaint = $data['chief_complaint'] ?? null;
            $this->primary_diagnosis = $data['primary_diagnosis'] ?? null;
            $this->recommended_treatment = $data['recommended_treatment'] ?? null;
            $this->procedures_performed = $data['procedures_performed'] ?? null;
            $this->medication_prescribed = $data['medication_prescribed'] ?? null;
            $this->followup_next_visit = $data['followup_next_visit'] ?? null;
        }
    }
    
    public function toArray()
    {
        return [
            'id' => $this->id,
            'date' => $this->date,
            'pid' => $this->pid,
            'encounter' => $this->encounter,
            'user' => $this->user,
            'groupname' => $this->groupname,
            'authorized' => $this->authorized,
            'activity' => $this->activity,
            'chief_complaint' => $this->chief_complaint,
            'primary_diagnosis' => $this->primary_diagnosis,
            'recommended_treatment' => $this->recommended_treatment,
            'procedures_performed' => $this->procedures_performed,
            'medication_prescribed' => $this->medication_prescribed,
            'followup_next_visit' => $this->followup_next_visit
        ];
    }
}
