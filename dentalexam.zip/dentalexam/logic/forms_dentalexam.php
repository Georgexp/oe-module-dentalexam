<?php
include_once("../../globals.php");
include_once($GLOBALS["srcdir"] . "/api.inc");

if (!acl_check('patients', 'med')) {
    die(xlt("Access not allowed"));
}

$formid = $_REQUEST['id'] ?? 0;
$viewmode = $_REQUEST['mode'] == 'view';

if ($viewmode) {
    $obj = sqlQuery("SELECT * FROM form_dentalexam WHERE id = ?", array($formid));
} else {
    $obj = sqlQuery("SELECT * FROM form_dentalexam WHERE id = ?", array($formid));
}

if ($_POST['form_save']) {
    $id = 0 + (empty($_POST['id']) ? 0 : $_POST['id']);
    $date = fixDate($_POST['date']);
    $ChiefComplaint = $_POST['ChiefComplaint'];
    $PrimaryDiagnosis = $_POST['PrimaryDiagnosis'];
    $RecommendedTreatment = $_POST['RecommendedTreatment'];
    $ProceduresPerformed = $_POST['ProceduresPerformed'];
    $MedicationPrescribed = $_POST['MedicationPrescribed'];
    $FollowUpNextVisit = $_POST['FollowUpNextVisit'];
    $Legend = $_POST['Legend'];

    if ($id) {
        sqlStatement("UPDATE form_dentalexam SET date = ?, ChiefComplaint = ?, PrimaryDiagnosis = ?, RecommendedTreatment = ?, ProceduresPerformed = ?, MedicationPrescribed = ?, FollowUpNextVisit = ?, Legend = ? WHERE id = ?", array($date, $ChiefComplaint, $PrimaryDiagnosis, $RecommendedTreatment, $ProceduresPerformed, $MedicationPrescribed, $FollowUpNextVisit, $Legend, $id));
    } else {
        sqlInsert("INSERT INTO form_dentalexam (date, pid, user, groupname, authorized, activity, encounter, ChiefComplaint, PrimaryDiagnosis, RecommendedTreatment, ProceduresPerformed, MedicationPrescribed, FollowUpNextVisit, Legend) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", array($date, $_SESSION['pid'], $_SESSION['authUser'], $_SESSION['authProvider'], 1, 1, $_SESSION['encounter'], $ChiefComplaint, $PrimaryDiagnosis, $RecommendedTreatment, $ProceduresPerformed, $MedicationPrescribed, $FollowUpNextVisit, $Legend));
        $id = sqlInsertId();
    }
}

$assign = array(
    'ChiefComplaint' => $obj['ChiefComplaint'] ?? '',
    'PrimaryDiagnosis' => $obj['PrimaryDiagnosis'] ?? '',
    'RecommendedTreatment' => $obj['RecommendedTreatment'] ?? '',
    'ProceduresPerformed' => $obj['ProceduresPerformed'] ?? '',
    'MedicationPrescribed' => $obj['MedicationPrescribed'] ?? '',
    'FollowUpNextVisit' => $obj['FollowUpNextVisit'] ?? '',
    'Legend' => $obj['Legend'] ?? '',
);

include("templates/dentalexam.tpl");
?>