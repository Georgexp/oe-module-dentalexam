CREATE TABLE IF NOT EXISTS `form_dental_exam` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `pid` bigint(20) NOT NULL DEFAULT 0,
  `encounter` bigint(20) NOT NULL DEFAULT 0,
  `user` varchar(255) DEFAULT NULL,
  `groupname` varchar(255) DEFAULT NULL,
  `authorized` tinyint(4) NOT NULL DEFAULT 0,
  `activity` tinyint(4) NOT NULL DEFAULT 1,
  `chief_complaint` text DEFAULT NULL,
  `primary_diagnosis` text DEFAULT NULL,
  `recommended_treatment` text DEFAULT NULL,
  `procedures_performed` text DEFAULT NULL,
  `medication_prescribed` text DEFAULT NULL,
  `followup_next_visit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;
