<?php
/**
 * @package   OpenEMR
 * @link      http://www.open-emr.org
 *
 * @author    OpenEMR
 * @copyright Copyright (c) 2022
 * @license   GNU General Public License 3
 */

require_once dirname(__FILE__, 5) . '/globals.php';
require_once dirname(__DIR__) . '/vendor/autoload.php';

use OpenEMR\Modules\DentalExam\Controllers\DentalExamController;

$controller = new DentalExamController();
echo $controller->index();
