<?php

namespace OpenEMR\Modules\DentalExam\Controllers;

/**
 * @package   OpenEMR
 * @link      http://www.open-emr.org
 *
 * @author    OpenEMR
 * @copyright Copyright (c) 2022
 * @license   GNU General Public License 3
 */

use OpenEMR\Common\Csrf\CsrfUtils;
use OpenEMR\Common\Twig\TwigContainer;
use OpenEMR\Modules\DentalExam\Models\DentalExam;
use OpenEMR\Modules\DentalExam\Services\DentalExamService;

class DentalExamController
{
    private $service;
    private $twig;

    public function __construct()
    {
        $this->service = new DentalExamService();
        $this->twig = (new TwigContainer(null, $GLOBALS['kernel']))->getTwig();
    }

    public function index()
    {
        $pid = $_SESSION['pid'] ?? null;
        $encounter = $_SESSION['encounter'] ?? null;
        
        if (!$pid || !$encounter) {
            echo "Patient or encounter not selected.";
            exit;
        }
        
        $dentalExam = $this->service->getByEncounter($pid, $encounter);
        
        if (!$dentalExam) {
            $dentalExam = new DentalExam([
                'pid' => $pid,
                'encounter' => $encounter,
                'user' => $_SESSION['authUser'],
                'groupname' => $_SESSION['authProvider'],
                'authorized' => 1,
                'activity' => 1
            ]);
        }
        
        return $this->renderView('dental_exam.php', [
            'csrfToken' => CsrfUtils::collectCsrfToken(),
            'dentalExam' => $dentalExam
        ]);
    }

    public function save()
    {
        if (!CsrfUtils::verifyCsrfToken($_POST["csrf_token_form"])) {
            CsrfUtils::csrfNotVerified();
        }
        
        $id = $_POST['id'] ?? null;
        $pid = $_SESSION['pid'] ?? null;
        $encounter = $_SESSION['encounter'] ?? null;
        
        if (!$pid || !$encounter) {
            echo "Patient or encounter not selected.";
            exit;
        }
        
        $data = [
            'id' => $id,
            'pid' => $pid,
            'encounter' => $encounter,
            'user' => $_SESSION['authUser'],
            'groupname' => $_SESSION['authProvider'],
            'authorized' => 1,
            'activity' => 1,
            'chief_complaint' => $_POST['chief_complaint'] ?? '',
            'primary_diagnosis' => $_POST['primary_diagnosis'] ?? '',
            'recommended_treatment' => $_POST['recommended_treatment'] ?? '',
            'procedures_performed' => $_POST['procedures_performed'] ?? '',
            'medication_prescribed' => $_POST['medication_prescribed'] ?? '',
            'followup_next_visit' => $_POST['followup_next_visit'] ?? ''
        ];
        
        $dentalExam = new DentalExam($data);
        $this->service->save($dentalExam);
        
        // Redirect back to the encounter
        header("Location: " . $GLOBALS['webroot'] . "/interface/patient_file/encounter/encounter_top.php");
        exit;
    }

    protected function renderView($template, $data = [])
    {
        $templatePath = dirname(__DIR__) . "/views/$template";
        
        if (file_exists($templatePath)) {
            extract($data);
            ob_start();
            include $templatePath;
            return ob_get_clean();
        }
        
        throw new \RuntimeException("Template $template not found");
    }
}
