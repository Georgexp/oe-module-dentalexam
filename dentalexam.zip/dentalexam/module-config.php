<?php
/**
 * @package   OpenEMR
 * @link      http://www.open-emr.org
 *
 * @author    OpenEMR
 * @copyright Copyright (c) 2022
 * @license   GNU General Public License 3
 */

namespace OpenEMR\Modules\DentalExam;

/**
 * @global OpenEMR\Core\ModuleDispatcher $event_dispatcher
 * @global                               $eventDispatcher
 */

use OpenEMR\Common\Logging\SystemLogger;
use OpenEMR\Core\ModuleDispatcherFactory;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

if (empty($GLOBALS['modules_application_name'])) {
    // for when this is called from the OpenEMR module system
    if (!empty($eventDispatcher)) {
        if (!$eventDispatcher instanceof EventDispatcherInterface) {
            $eventDispatcher = null;
        }
    }
} else if (!empty($GLOBALS['kernel'])) {
    // this is for when the module system is bootstrapped from OpenEMR
    $moduleDispatcherFactory = new ModuleDispatcherFactory();
    $eventDispatcher = $moduleDispatcherFactory->createEventDispatcher();
}

if (empty($eventDispatcher)) {
    return;
}

$bootstrap = new Bootstrap($eventDispatcher, new SystemLogger());
$bootstrap->subscribeToEvents();
