<?php
/**
 * @package   OpenEMR
 * @link      http://www.open-emr.org
 *
 * @author    OpenEMR
 * @copyright Copyright (c) 2022
 * @license   GNU General Public License 3
 */
?>
<table class="table">
    <tr>
        <td><span class="font-weight-bold"><?php echo xlt('Legend:'); ?></span> <?php echo xlt('A=Abscessed C=Caries F=Fracture E=Existing Restoration M=Mobile X=To be extracted'); ?></td>
    </tr>
    <tr>
        <td><span class="font-weight-bold"><?php echo xlt('Chief Complaint:'); ?></span> <?php echo text($dentalExam->chief_complaint ?? ''); ?></td>
    </tr>
    <tr>
        <td><span class="font-weight-bold"><?php echo xlt('Primary Diagnosis:'); ?></span> <?php echo text($dentalExam->primary_diagnosis ?? ''); ?></td>
    </tr>
    <tr>
        <td><span class="font-weight-bold"><?php echo xlt('Recommended Treatment:'); ?></span> <?php echo text($dentalExam->recommended_treatment ?? ''); ?></td>
    </tr>
    <tr>
        <td><span class="font-weight-bold"><?php echo xlt('Procedures Performed:'); ?></span> <?php echo text($dentalExam->procedures_performed ?? ''); ?></td>
    </tr>
    <tr>
        <td><span class="font-weight-bold"><?php echo xlt('Medication Prescribed:'); ?></span> <?php echo text($dentalExam->medication_prescribed ?? ''); ?></td>
    </tr>
    <tr>
        <td><span class="font-weight-bold"><?php echo xlt('Follow Up/Next Visit:'); ?></span> <?php echo text($dentalExam->followup_next_visit ?? ''); ?></td>
    </tr>
</table>
