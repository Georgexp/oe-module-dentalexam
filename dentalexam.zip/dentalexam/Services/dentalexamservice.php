<?php

namespace OpenEMR\Modules\DentalExam\Services;

/**
 * @package   OpenEMR
 * @link      http://www.open-emr.org
 *
 * @author    OpenEMR
 * @copyright Copyright (c) 2022
 * @license   GNU General Public License 3
 */

use OpenEMR\Common\Database\QueryUtils;
use OpenEMR\Modules\DentalExam\Models\DentalExam;
use OpenEMR\Services\BaseService;

class DentalExamService extends BaseService
{
    const TABLE_NAME = 'form_dental_exam';

    public function __construct()
    {
        parent::__construct(self::TABLE_NAME);
    }

    public function getById($id)
    {
        $sql = "SELECT * FROM " . self::TABLE_NAME . " WHERE id = ?";
        $result = QueryUtils::fetchRecords($sql, [$id]);
        
        if (!empty($result[0])) {
            return new DentalExam($result[0]);
        }
        
        return null;
    }

    public function getByEncounter($pid, $encounter)
    {
        $sql = "SELECT * FROM " . self::TABLE_NAME . " WHERE pid = ? AND encounter = ? ORDER BY id DESC";
        $result = QueryUtils::fetchRecords($sql, [$pid, $encounter]);
        
        if (!empty($result[0])) {
            return new DentalExam($result[0]);
        }
        
        return null;
    }

    public function save(DentalExam $dentalExam)
    {
        $data = $dentalExam->toArray();
        
        if (empty($data['id'])) {
            // It's a new form
            unset($data['id']);
            $data['date'] = date('Y-m-d H:i:s');
            $id = $this->insert($data);
            
            // Add to forms table
            $formData = [
                'form_name' => 'Dental Exam',
                'form_id' => $id,
                'pid' => $data['pid'],
                'user' => $data['user'],
                'groupname' => $data['groupname'],
                'authorized' => $data['authorized'],
                'date' => $data['date'],
                'encounter' => $data['encounter'],
                'formdir' => 'dentalexam',
                'deleted' => 0
            ];
            
            QueryUtils::sqlInsert('forms', $formData);
            
            return $id;
        } else {
            // It's an existing form
            $data['date'] = date('Y-m-d H:i:s');
            return $this->update($data['id'], $data);
        }
    }
    
    public function generateReport($id)
    {
        $exam = $this->getById($id);
        if (!$exam) {
            return '';
        }
        
        $html = '<table class="table">';
        $html .= '<tr><td><span class="font-weight-bold">Legend:</span> A=Abscessed C=Caries F=Fracture E=Existing Restoration M=Mobile X=To be extracted</td></tr>';
        $html .= '<tr><td><span class="font-weight-bold">Chief Complaint:</span> ' . text($exam->chief_complaint) . '</td></tr>';
        $html .= '<tr><td><span class="font-weight-bold">Primary Diagnosis:</span> ' . text($exam->primary_diagnosis) . '</td></tr>';
        $html .= '<tr><td><span class="font-weight-bold">Recommended Treatment:</span> ' . text($exam->recommended_treatment) . '</td></tr>';
        $html .= '<tr><td><span class="font-weight-bold">Procedures Performed:</span> ' . text($exam->procedures_performed) . '</td></tr>';
        $html .= '<tr><td><span class="font-weight-bold">Medication Prescribed:</span> ' . text($exam->medication_prescribed) . '</td></tr>';
        $html .= '<tr><td><span class="font-weight-bold">Follow Up/Next Visit:</span> ' . text($exam->followup_next_visit) . '</td></tr>';
        $html .= '</table>';
        
        return $html;
    }
}
