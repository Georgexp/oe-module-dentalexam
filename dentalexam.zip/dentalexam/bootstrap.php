<?php

namespace OpenEMR\Modules\DentalExam;

/**
 * @package   OpenEMR
 * @link      http://www.open-emr.org
 *
 * @author    OpenEMR
 * @copyright Copyright (c) 2022
 * @license   GNU General Public License 3
 */

use OpenEMR\Common\Logging\SystemLogger;
use OpenEMR\Common\Twig\TwigContainer;
use OpenEMR\Core\Kernel;
use OpenEMR\Events\Core\TemplatePageEvent;
use OpenEMR\Events\Globals\GlobalsInitializedEvent;
use OpenEMR\Events\Main\Menu\MainMenuRole;
use OpenEMR\Events\PatientDemographics\RenderEvent;
use OpenEMR\Menu\MenuEvent;
use OpenEMR\Services\Globals\GlobalSetting;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Error\SyntaxError;

class Bootstrap
{
    const MODULE_NAME = "DentalExam";
    const MODULE_MENU_NAME = "Dental Exam";
    const MODULE_INSTALLATION_PATH = "/interface/modules/custom_modules/";

    /**
     * @var EventDispatcherInterface The object responsible for sending and subscribing to events through the OpenEMR system
     */
    private $eventDispatcher;

    /**
     * @var SystemLogger
     */
    private $logger;

    public function __construct(EventDispatcherInterface $eventDispatcher, ?SystemLogger $logger = null)
    {
        $this->eventDispatcher = $eventDispatcher;
        $this->logger = $logger ?? new SystemLogger();
    }

    public function subscribeToEvents()
    {
        $this->addGlobalSettings();
        $this->registerMenuItems();
    }

    public function addGlobalSettings()
    {
        // No global settings needed for this module
    }

    public function registerMenuItems()
    {
        /**
         * @var EventDispatcherInterface $eventDispatcher
         * @var array $module
         */
        $this->eventDispatcher->addListener(MenuEvent::MENU_UPDATE, function (MenuEvent $menuEvent) {
            $menu = $menuEvent->getMenu();

            $menuItem = new \stdClass();
            $menuItem->requirement = 0;
            $menuItem->target = 'den';
            $menuItem->menu_id = 'den0';
            $menuItem->label = xlt("Dental Exam");
            $menuItem->url = "/interface/modules/custom_modules/oe-module-dentalexam/public/index.php";
            $menuItem->children = [];
            $menuItem->acl_req = ["patients", "demo"];
            $menuItem->global_req = [];

            foreach ($menu as $item) {
                if ($item->menu_id == 'patimg') {
                    $item->children[] = $menuItem;
                    break;
                }
            }

            $menuEvent->setMenu($menu);
        });

        $this->eventDispatcher->addListener(MenuEvent::MENU_RESTRICT_PATIENT, function (MenuEvent $menuEvent) {
            $isEncounter = $menuEvent->isEncounter();
            $menu = $menuEvent->getMenu();

            // Since this is an encounter form, only show it in the encounter context
            if ($isEncounter) {
                $clinical = [];
                foreach ($menu as $item) {
                    if ($item->menu_id == 'clinical') {
                        $dropdownMenuItem = new \stdClass();
                        $dropdownMenuItem->requirement = 0;
                        $dropdownMenuItem->target = 'den';
                        $dropdownMenuItem->menu_id = 'den0';
                        $dropdownMenuItem->label = xlt("Dental Exam");
                        $dropdownMenuItem->url = "/interface/modules/custom_modules/oe-module-dentalexam/public/index.php";
                        $dropdownMenuItem->children = [];
                        $dropdownMenuItem->acl_req = ["patients", "demo"];
                        $dropdownMenuItem->global_req = [];

                        $item->children[] = $dropdownMenuItem;
                        break;
                    }
                }
            }
            $menuEvent->setMenu($menu);
        });
    }
}
